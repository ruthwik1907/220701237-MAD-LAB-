package com.androidlead.tablethai

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import android.speech.tts.TextToSpeech

import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private var isDarkMode = false
    private lateinit var etDisease: AutoCompleteTextView
    private lateinit var etMobile: EditText
    private lateinit var tvResult: TextView
    private lateinit var btnSuggest: Button
    private lateinit var btnClear: Button
    private lateinit var btnMic: ImageButton
    private val REQ_CODE_SPEECH_INPUT = 100
    private lateinit var tts: TextToSpeech




    private val tabletMap = mapOf(
        "cold" to "Paracetamol",
        "fever" to "Dolo 650",
        "headache" to "Aspirin",
        "cough" to "Benadryl",
        "diabetes" to "Metformin",
        "bp" to "Amlodipine",
        "stomach pain" to "Buscopan",
        "asthma" to "Salbutamol",
        "flu" to "Tamiflu",
        "migraine" to "Sumatriptan",
        "acidity" to "Pantoprazole",
        "gastric" to "Omeprazole",
        "allergy" to "Cetirizine",
        "vomiting" to "Ondansetron",
        "diarrhea" to "Loperamide",
        "constipation" to "Lactulose",
        "skin allergy" to "Levocetirizine",
        "anxiety" to "Alprazolam",
        "depression" to "Fluoxetine",
        "insomnia" to "Zolpidem",
        "eczema" to "Hydrocortisone",
        "acne" to "Clindamycin",
        "arthritis" to "Ibuprofen",
        "joint pain" to "Diclofenac",
        "back pain" to "Naproxen",
        "muscle pain" to "Flexon",
        "eye infection" to "Ciprofloxacin eye drops",
        "ear infection" to "Ofloxacin ear drops",
        "toothache" to "Ketorolac",
        "throat pain" to "Strepsils",
        "tonsillitis" to "Amoxicillin",
        "sinus" to "Xylometazoline",
        "menstrual pain" to "Meftal Spas",
        "pcod" to "Diane 35",
        "thyroid" to "Thyronorm",
        "cholesterol" to "Atorvastatin",
        "heartburn" to "Ranitidine",
        "ulcer" to "Sucralfate",
        "gas trouble" to "Domperidone",
        "motion sickness" to "Avomine",
        "fatigue" to "Revital",
        "weakness" to "Becadexamin",
        "low bp" to "Fludrocortisone",
        "high bp" to "Losartan",
        "high sugar" to "Glycomet",
        "low sugar" to "Glucagon",
        "piles" to "Pilex",
        "urine infection" to "Nitrofurantoin",
        "kidney stone" to "Tamsulosin",
        "gout" to "Allopurinol",
        "obesity" to "Orlistat",
        "hair fall" to "Minoxidil",
        "dandruff" to "Ketoconazole",
        "baldness" to "Finasteride",
        "dry eyes" to "Refresh Tears",
        "psoriasis" to "Clobetasol",
        "ringworm" to "Clotrimazole",
        "fungal infection" to "Fluconazole",
        "bacterial infection" to "Amoxicillin",
        "viral fever" to "Paracetamol",
        "food poisoning" to "Norfloxacin",
        "typhoid" to "Cefixime",
        "malaria" to "Artemether",
        "dengue" to "Papaya Leaf Extract",
        "chikungunya" to "Paracetamol",
        "hepatitis" to "Tenofovir",
        "jaundice" to "Liv 52",
        "cold sore" to "Acyclovir",
        "shingles" to "Valacyclovir",
        "chest pain" to "Nitroglycerin",
        "angina" to "Isosorbide Mononitrate",
        "stroke" to "Aspirin",
        "paralysis" to "Physiotherapy + B Complex",
        "pneumonia" to "Azithromycin",
        "bronchitis" to "Levofloxacin",
        "tb" to "Rifampicin",
        "covid" to "Ivermectin (under guidance)",
        "epilepsy" to "Valproate",
        "fits" to "Carbamazepine",
        "vertigo" to "Betahistine",
        "parkinson's" to "Levodopa",
        "alzheimer's" to "Donepezil",
        "memory loss" to "Piracetam",
        "burns" to "Silver Sulfadiazine",
        "wounds" to "Betadine",
        "cuts" to "Neosporin",
        "nausea" to "Domperidone",
        "dehydration" to "ORS",
        "heat stroke" to "Electral",
        "sunburn" to "Aloe Vera Gel",
        "itching" to "Cetrimide",
        "scabies" to "Permethrin",
        "bed sores" to "Povidone-Iodine",
        "bleeding" to "Tranexamic Acid",
        "low hemoglobin" to "Ferrous Sulfate",
        "vitamin d deficiency" to "Cholecalciferol",
        "calcium deficiency" to "Calcium Carbonate",
        "b12 deficiency" to "Methylcobalamin",
        "eye strain" to "Lubricant Drops",
        "smoking addiction" to "Nicotine Patch",
        "alcohol addiction" to "Disulfiram",
        "deworming" to "Albendazole",
        "worm infection" to "Mebendazole",
        "gas bloating" to "Simethicone"
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootLayout = findViewById<ScrollView>(R.id.rootLayout)
        val title = findViewById<TextView>(R.id.title)
        val etName = findViewById<EditText>(R.id.etName)
        val etMobile = findViewById<EditText>(R.id.etMobile)
        val etDisease = findViewById<AutoCompleteTextView>(R.id.etDisease)
        var btnMic = findViewById<ImageButton>(R.id.btnMic)
        val btnSuggest = findViewById<Button>(R.id.btnSuggest)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnToggleMode = findViewById<Button>(R.id.btnToggleMode)


        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, tabletMap.keys.toList())
        etDisease.setAdapter(adapter)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
            }
        }

        val btnSpeak = findViewById<Button>(R.id.btnSpeak)



        btnSuggest.setOnClickListener {
            val name = etName.text.toString().trim()
            val mobile = etMobile.text.toString().trim()
            val disease = etDisease.text.toString().trim().lowercase()
            val resultText = tvResult.text.toString()
            if (resultText.isNotEmpty()) {
                tts.speak(resultText, TextToSpeech.QUEUE_FLUSH, null, null)
            }
            if (name.isEmpty() || mobile.length != 10) {
                Toast.makeText(this, "Please enter a valid Name and 10-digit Mobile Number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val tablet = tabletMap[disease] ?: "No suggestion available for '$disease'"
            tvResult.text = "Hello $name!\nSuggested Tablet for $disease: $tablet"
        }

        btnClear.setOnClickListener {
            etName.text.clear()
            etMobile.text.clear()
            etDisease.text.clear()
            tvResult.text = ""
        }
        btnMic = findViewById(R.id.btnMic)

        btnMic.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak the disease")

            try {
                startActivityForResult(intent, REQ_CODE_SPEECH_INPUT)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Speech not supported", Toast.LENGTH_SHORT).show()
            }
        }
        btnToggleMode.setOnClickListener {
            if (isDarkMode) {
                rootLayout.setBackgroundColor(Color.parseColor("#F5F5F5"))
                title.setTextColor(Color.parseColor("#3F51B5"))
                tvResult.setTextColor(Color.BLACK)

                etName.setTextColor(Color.BLACK)
                etMobile.setTextColor(Color.BLACK)
                etDisease.setTextColor(Color.BLACK)

                btnSuggest.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#3F51B5")))
                btnClear.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#757575")))
                btnToggleMode.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#757575")))

                btnToggleMode.text = "Toggle Dark Mode"
                isDarkMode = false
            } else {
                rootLayout.setBackgroundColor(Color.parseColor("#121212"))
                title.setTextColor(Color.WHITE)
                tvResult.setTextColor(Color.WHITE)

                etName.setTextColor(Color.BLACK)
                etMobile.setTextColor(Color.BLACK)
                etDisease.setTextColor(Color.BLACK)

                btnSuggest.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#BB86FC")))
                btnClear.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#888888")))
                btnToggleMode.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#888888")))

                btnToggleMode.text = "Toggle Light Mode"
                isDarkMode = true
            }
        }
        btnSpeak.setOnClickListener {
            val resultText = tvResult.text.toString()
            if (resultText.isNotEmpty()) {
                tts.speak(resultText, TextToSpeech.QUEUE_FLUSH, null, null)
            } else {
                Toast.makeText(this, "No result to speak", Toast.LENGTH_SHORT).show()
            }
        }


    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQ_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!result.isNullOrEmpty()) {
                val spokenText = result[0]
                val etDisease = findViewById<AutoCompleteTextView>(R.id.etDisease)
                etDisease.setText(spokenText)
            }
        }
    }


    override fun onBackPressed() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Exit App")
        builder.setMessage("Are you sure you want to exit?")
        builder.setPositiveButton("Yes") { _, _ -> super.onBackPressed() }
        builder.setNegativeButton("No") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }
    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }

}
